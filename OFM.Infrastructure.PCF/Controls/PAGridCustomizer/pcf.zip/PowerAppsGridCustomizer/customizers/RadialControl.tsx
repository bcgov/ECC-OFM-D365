import * as React from 'react';
import { ReactNode, CSSProperties } from 'react';

interface RadialControlProps {
  children: ReactNode;
  size: string | number;
  color: string;
}

const RadialControl: React.FC<RadialControlProps> = ({ children, size, color }) => {
  const style: CSSProperties = {
    width: size,
    height: size,
    borderRadius: '50%',
    backgroundColor: color,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  };

  return <div style={style}>{children}</div>;
};

export default RadialControl;
